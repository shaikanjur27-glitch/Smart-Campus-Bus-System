import pandas as pd
import streamlit as st

# ---------------- PAGE CONFIGURATION ----------------
st.set_page_config(page_title="Smart Campus Bus System", page_icon=":bus:", layout="wide")

# ---------------- INITIALIZE DEMO DATA (kept in session memory) ----------------
if "db_initialized" not in st.session_state:
    st.session_state.users = {
        "STU001": {"name": "Amit Kumar", "role": "Student", "fee_paid": True, "stop": "Guntur Junction"},
        "STU002": {"name": "Sai Kiran", "role": "Student", "fee_paid": False, "stop": "Guntur Junction"},
        "DRV999": {"name": "Raju (Driver)", "role": "Driver", "fee_paid": True, "stop": None},
        "MGMT01": {"name": "Admin Office", "role": "Management", "fee_paid": True, "stop": None},
    }

    seats_list = []

    # Left side: 3-seater rows 1-11; row 1 reserved for faculty
    for r in range(1, 12):
        seat_type = "Faculty" if r == 1 else "Regular"
        for letter in ["A", "B", "C"]:
            seats_list.append({"id": f"L{r}{letter}", "row": r, "side": "Left (3-Seater)",
                               "type": seat_type, "status": "Available", "user": None})

    # Right side: 2-seater rows 1-12; row 1 reserved for faculty
    for r in range(1, 13):
        seat_type = "Faculty" if r == 1 else "Regular"
        for letter in ["D", "E"]:
            seats_list.append({"id": f"R{r}{letter}", "row": r, "side": "Right (2-Seater)",
                               "type": seat_type, "status": "Available", "user": None})

    # Last two seats are kept for emergencies
    seats_list[-1]["type"] = "Emergency"
    seats_list[-2]["type"] = "Emergency"

    st.session_state.seats = pd.DataFrame(seats_list)
    st.session_state.db_initialized = True

TOTAL_SEATS = len(st.session_state.seats)

# ---------------- HEADER ----------------
st.title(":bus: Smart Campus Bus Management System")
st.markdown("---")


def book_seat(seat_id, user_value):
    mask = st.session_state.seats["id"] == seat_id
    st.session_state.seats.loc[mask, ["status", "user"]] = ["Booked", user_value]


# ---------------- LOGIN ----------------
if "logged_in_user" not in st.session_state:
    st.subheader("Campus login")
    st.info("Demo logins use college IDs only. Add secure authentication before using real student data.")
    student_tab, driver_tab, management_tab = st.tabs(["Student", "Driver", "Management"])

    with student_tab:
        st.caption("Student demo IDs (management can add student profiles):")
        for sid, p in st.session_state.users.items():
            if p["role"] == "Student":
                st.markdown(f"- {sid} - {p['name']} ({'fee paid' if p['fee_paid'] else 'fee unpaid'})")
        with st.form("student_login_form"):
            student_id = st.text_input("Student college ID").strip().upper()
            student_login = st.form_submit_button("Log in as student", type="primary")
        if student_login:
            info = st.session_state.users.get(student_id)
            if info and info["role"] == "Student":
                if not info["fee_paid"]:
                    st.error("Access denied: management records show unpaid bus transport fees.")
                else:
                    st.session_state.logged_in_user = student_id
                    st.rerun()
            else:
                st.warning("Student ID not found. Ask management to add your profile.")

    with driver_tab:
        st.caption("Driver demo ID: **DRV999**")
        with st.form("driver_login_form"):
            driver_id = st.text_input("Driver college ID").strip().upper()
            driver_login = st.form_submit_button("Log in as driver", type="primary")
        if driver_login:
            info = st.session_state.users.get(driver_id)
            if info and info["role"] == "Driver":
                st.session_state.logged_in_user = driver_id
                st.rerun()
            else:
                st.warning("Driver ID not found.")

    with management_tab:
        st.caption("Management demo ID: **MGMT01**")
        with st.form("management_login_form"):
            mgmt_id = st.text_input("Management college ID").strip().upper()
            mgmt_login = st.form_submit_button("Log in as management", type="primary")
        if mgmt_login:
            info = st.session_state.users.get(mgmt_id)
            if info and info["role"] == "Management":
                st.session_state.logged_in_user = mgmt_id
                st.rerun()
            else:
                st.warning("Management ID not found.")

else:
    uid = st.session_state.logged_in_user
    profile = st.session_state.users[uid]

    st.sidebar.markdown(f"### :bust_in_silhouette: Active Account:\n**{profile['name']}**")
    st.sidebar.caption(f"Access Level: {profile['role']}")
    if st.sidebar.button("Log Out Account", type="secondary"):
        del st.session_state.logged_in_user
        st.rerun()

    df = st.session_state.seats

    # ---------- 1. STUDENT VIEW ----------
    if profile["role"] == "Student":
        st.header(":mortar_board: Passenger Registration Panel")
        existing = df[df["user"] == uid]

        if not existing.empty:
            st.success(f"Seat **{existing.iloc[0]['id']}** is locked and allocated to your College ID.")
            if st.button("Cancel My Ticket (Before Cutoff)", type="primary"):
                st.session_state.seats.loc[st.session_state.seats["user"] == uid,
                                           ["status", "user"]] = ["Available", None]
                st.toast("Reservation cancelled successfully.")
                st.rerun()
        else:
            open_seats = df[(df["type"] == "Regular") & (df["status"] == "Available")]
            if open_seats.empty:
                st.error("Capacity full: all regular seats are booked. No standing passengers permitted.")
            else:
                st.info(f"Seats available: **{len(open_seats)}** left on this route.")
                chosen = st.selectbox("Select your seat:", open_seats["id"].tolist())
                if st.button("Reserve My Seat", type="primary"):
                    book_seat(chosen, uid)
                    st.success(f"Seat {chosen} confirmed! Please report to your stop on time.")
                    st.rerun()

    # ---------- 2. DRIVER VIEW ----------
    elif profile["role"] == "Driver":
        st.header(":clipboard: Digital Driver Manifest Console")
        c1, c2 = st.columns(2)

        with c1:
            st.subheader("Teacher Boarding Log")
            open_fac = df[(df["type"] == "Faculty") & (df["status"] == "Available")]
            if not open_fac.empty:
                teacher = st.text_input("Boarding faculty member's name:")
                target = open_fac.iloc[0]["id"]
                if st.button(f"Register Faculty onto Seat ({target})"):
                    if teacher.strip():
                        book_seat(target, f"FAC-{teacher.strip()}")
                        st.success(f"Locked faculty seat {target} for {teacher.strip()}")
                        st.rerun()
                    else:
                        st.warning("Please enter the faculty member's name.")
            else:
                st.warning("All designated faculty seats are filled.")

        with c2:
            st.subheader("Spot Emergency Booking")
            open_em = df[(df["type"] == "Emergency") & (df["status"] == "Available")]
            if not open_em.empty:
                st.info(f"Available emergency seats: {len(open_em)} left.")
                em_id = st.text_input("Verify and enter stranded student ID:").strip().upper()
                if st.button("Unlock 1 Emergency Seat"):
                    if em_id:
                        book_seat(open_em.iloc[0]["id"], em_id)
                        st.success("Emergency seat assigned.")
                        st.rerun()
                    else:
                        st.warning("Please enter the student ID.")
            else:
                st.error("No emergency seats remain.")

    # ---------- 3. MANAGEMENT VIEW ----------
    elif profile["role"] == "Management":
        st.header(":bar_chart: Transport Fleet Dashboard")
        booked_total = int((df["status"] == "Booked").sum())
        col1, col2, col3 = st.columns(3)
        col1.metric("Passengers Booked", f"{booked_total} / {TOTAL_SEATS}")
        col2.metric("Seats Remaining", TOTAL_SEATS - booked_total)
        col3.metric("Emergency Seats Remaining",
                    int(((df["type"] == "Emergency") & (df["status"] == "Available")).sum()))

        st.subheader("Passengers by Boarding Stop")
        stops = [st.session_state.users[row["user"]]["stop"]
                 for _, row in df.iterrows()
                 if row["status"] == "Booked" and row["user"] in st.session_state.users]
        if stops:
            st.bar_chart(pd.Series(stops).value_counts())
        else:
            st.info("No student bookings to display yet.")

        st.subheader("Manage Student Profiles")
        st.caption("Enter the official student name, college ID, boarding stop and transport-fee status.")
        with st.form("student_profile_form"):
            new_id = st.text_input("College ID").strip().upper()
            new_name = st.text_input("Student name")
            new_stop = st.text_input("Boarding stop")
            new_fee = st.checkbox("Transport fee paid")
            save_student = st.form_submit_button("Save Student Profile")

        if save_student:
            if not new_id or not new_name.strip() or not new_stop.strip():
                st.error("Enter a college ID, student name, and boarding stop.")
            elif new_id in st.session_state.users and st.session_state.users[new_id]["role"] != "Student":
                st.error("That college ID belongs to a non-student account and cannot be changed.")
            else:
                st.session_state.users[new_id] = {"name": new_name.strip(), "role": "Student",
                                                  "fee_paid": new_fee, "stop": new_stop.strip()}
                st.success(f"Student profile saved for {new_name.strip()} ({new_id}).")
                st.rerun()

        students = [{"College ID": sid, "Name": p["name"], "Boarding stop": p["stop"],
                     "Fee paid": "Yes" if p["fee_paid"] else "No"}
                    for sid, p in st.session_state.users.items() if p["role"] == "Student"]
        if students:
            st.dataframe(pd.DataFrame(students), hide_index=True, width="stretch")

    # ---------- BUS SEAT MAP ----------
    st.markdown("---")
    st.subheader(":world_map: Real-Time Bus Seat Layout")
    st.caption(
        ":large_red_square: Booked   :large_green_square: Available   "
        ":star: Faculty   :rotating_light: Emergency   :seat: Regular"
    )
    df = st.session_state.seats
    icons = {"Faculty": ":star:", "Emergency": ":rotating_light:", "Regular": ":seat:"}

    def draw_row(row_seats, widths):
        cols = st.columns(widths)
        for i, (_, seat) in enumerate(row_seats.iterrows()):
            colour = ":large_red_square:" if seat["status"] == "Booked" else ":large_green_square:"
            cols[i].markdown(f"{colour} **{seat['id']}**\n\n{icons[seat['type']]} `{seat['type']}`")

    st.markdown("**Left side (3-seater rows 1-11)**")
    for r in range(1, 12):
        draw_row(df[(df["side"] == "Left (3-Seater)") & (df["row"] == r)], [1, 1, 1, 6])

    st.markdown("**:walking: AISLE WALKWAY**")

    st.markdown("**Right side (2-seater rows 1-12)**")
    for r in range(1, 13):
        draw_row(df[(df["side"] == "Right (2-Seater)") & (df["row"] == r)], [1, 1, 7])
