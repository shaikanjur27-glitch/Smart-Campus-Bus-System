CREATE DATABASE IF NOT EXISTS smartcampus_db;
USE smartcampus_db;

-- Drop old tables so structural changes apply cleanly
DROP TABLE IF EXISTS boarding_logs;
DROP TABLE IF EXISTS active_fleet;
DROP TABLE IF EXISTS campus_users;

-- Users: students, drivers and management
CREATE TABLE campus_users (
    barcode_id    VARCHAR(50) PRIMARY KEY,
    full_name     VARCHAR(100) NOT NULL,
    role          ENUM('Student', 'Driver', 'Management') NOT NULL,
    fee_paid      BOOLEAN NOT NULL DEFAULT FALSE,
    boarding_stop VARCHAR(100)
);

-- Fleet capacity, tracked separately for morning and evening shifts
CREATE TABLE active_fleet (
    bus_id                    VARCHAR(50),
    shift_type                ENUM('Morning', 'Evening'),
    three_seater_faculty_left INT NOT NULL,   -- Row 1 of 3-seaters (max 3)
    three_seater_student_left INT NOT NULL,   -- Rows 2-11 of 3-seaters (max 30)
    two_seater_faculty_left   INT NOT NULL,   -- Row 1 of 2-seaters (max 2)
    two_seater_student_left   INT NOT NULL,   -- Rows 2-12 of 2-seaters (max 22)
    PRIMARY KEY (bus_id, shift_type)
);

-- Boarding logs: which shift each student boarded
CREATE TABLE boarding_logs (
    log_id        INT AUTO_INCREMENT PRIMARY KEY,
    barcode_id    VARCHAR(50),
    bus_id        VARCHAR(50),
    shift_type    VARCHAR(20),
    seat_assigned VARCHAR(50),
    status        VARCHAR(50),
    scanned_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (barcode_id) REFERENCES campus_users(barcode_id)
);

-- Seed demo data
INSERT INTO campus_users VALUES
('STU001', 'Amit Kumar',    'Student',    TRUE,  'Guntur Junction'),
('STU002', 'Sai Kiran',     'Student',    FALSE, 'Guntur Junction'),
('DRV999', 'Raju (Driver)', 'Driver',     TRUE,  NULL),
('MGMT01', 'Admin Office',  'Management', TRUE,  NULL);

INSERT INTO active_fleet VALUES
('BUS-A', 'Morning', 3, 30, 2, 22),
('BUS-A', 'Evening', 3, 30, 2, 22);
